import { useState, useRef, useCallback, useEffect } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality, FunctionDeclaration, Type } from '@google/genai';
import { ConnectionState, OrderDetails, ChatMessage } from '../types';
import { base64ToUint8Array, decodeAudioData, createPcmBlob } from '../utils/audioUtils';

// Tool Definition
const submitOrderFunctionDeclaration: FunctionDeclaration = {
  name: 'submitOrder',
  description: 'Submits the final coffee order after all details (drink, size, milk, extras, name) are collected.',
  parameters: {
    type: Type.OBJECT,
    properties: {
      drinkType: { type: Type.STRING, description: 'The type of coffee drink (e.g., Latte, Cappuccino).' },
      size: { type: Type.STRING, description: 'The size of the drink (Small, Medium, Large).' },
      milk: { type: Type.STRING, description: 'The type of milk (Regular, Oat, Almond, etc.).' },
      extras: { 
        type: Type.ARRAY, 
        items: { type: Type.STRING },
        description: 'List of extras (e.g., Sugar, Vanilla Syrup).' 
      },
      name: { type: Type.STRING, description: 'The name of the customer.' }
    },
    required: ['drinkType', 'size', 'milk', 'name']
  }
};

const SYSTEM_INSTRUCTION = `
You are Dragon Sage, a calm, wise, mythical voice agent with a deep, knowledgeable tone.
You assist humans with information, respond clearly, and speak like a gentle, ancient dragon mentor.

🏰 Additional Role – Barista of Dragon Coffee Bite
Dragon Sage also works as a friendly barista at the enchanted café called Dragon Coffee Bite.

📜 BARISTA RULES
When the user asks to order coffee or discusses drinks, switch to Barista Mode.
Start with a warm, fantasy-style barista greeting.
Ask questions ONE by ONE in this exact order:
1. Drink type
2. Size
3. Milk type
4. Extra add-ons (whipped cream, caramel, sugar, etc.)
5. Customer name

❌ Do NOT confirm any order until ALL fields are collected.

✔️ After all details are collected:
1. Speak a confirmation similar to: "🔥 ORDER BREWED BY DRAGON SAGE. Here is your enchanted coffee order..."
2. IMMEDIATELY call the 'submitOrder' tool with the order details. This is how you "output the JSON".

🐉 Maintain a wise, friendly tone like a café dragon serving magical coffee. 
Do not break character.
`;

export const useDragonSage = () => {
  const [connectionState, setConnectionState] = useState<ConnectionState>(ConnectionState.DISCONNECTED);
  const [volume, setVolume] = useState<number>(0);
  const [completedOrder, setCompletedOrder] = useState<OrderDetails | null>(null);
  const [error, setError] = useState<string | null>(null);
  
  // Conversation State
  const [conversation, setConversation] = useState<ChatMessage[]>([]);
  const [realtimeUser, setRealtimeUser] = useState<string>('');
  const [realtimeModel, setRealtimeModel] = useState<string>('');

  // Audio Context Refs
  const inputAudioContextRef = useRef<AudioContext | null>(null);
  const outputAudioContextRef = useRef<AudioContext | null>(null);
  const inputSourceRef = useRef<MediaStreamAudioSourceNode | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const outputNodeRef = useRef<GainNode | null>(null);
  const audioSourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  
  // Logic Refs
  const nextStartTimeRef = useRef<number>(0);
  const sessionPromiseRef = useRef<Promise<any> | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  
  // Transcription Accumulation Refs
  const currentInputRef = useRef<string>('');
  const currentOutputRef = useRef<string>('');

  const disconnect = useCallback(() => {
    // Stop Microphone Stream
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }

    // Close Audio Contexts
    if (inputAudioContextRef.current) {
      inputAudioContextRef.current.close();
      inputAudioContextRef.current = null;
    }
    if (outputAudioContextRef.current) {
      outputAudioContextRef.current.close();
      outputAudioContextRef.current = null;
    }

    // Stop Audio Sources
    audioSourcesRef.current.forEach(source => {
      try { source.stop(); } catch (e) {}
    });
    audioSourcesRef.current.clear();

    // Reset State
    setConnectionState(ConnectionState.DISCONNECTED);
    setVolume(0);
    sessionPromiseRef.current = null;
    
    // Note: We do NOT clear conversation history here so users can see it after disconnect.
    // We only reset realtime transcription.
    currentInputRef.current = '';
    currentOutputRef.current = '';
    setRealtimeUser('');
    setRealtimeModel('');
  }, []);

  const connect = useCallback(async () => {
    try {
      if (!process.env.API_KEY) {
        throw new Error("API Key not found in environment.");
      }

      setConnectionState(ConnectionState.CONNECTING);
      setError(null);
      setCompletedOrder(null);
      setConversation([]); // Clear previous conversation on new connect
      setRealtimeUser('');
      setRealtimeModel('');
      currentInputRef.current = '';
      currentOutputRef.current = '';

      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      // Initialize Audio Contexts
      inputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      outputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      
      outputNodeRef.current = outputAudioContextRef.current.createGain();
      outputNodeRef.current.connect(outputAudioContextRef.current.destination);

      // Get Microphone
      streamRef.current = await navigator.mediaDevices.getUserMedia({ audio: true });

      const config = {
        model: 'gemini-2.5-flash-native-audio-preview-09-2025',
        systemInstruction: SYSTEM_INSTRUCTION,
        tools: [{ functionDeclarations: [submitOrderFunctionDeclaration] }],
      };

      const sessionPromise = ai.live.connect({
        model: config.model,
        config: {
          responseModalities: [Modality.AUDIO],
          systemInstruction: config.systemInstruction,
          tools: config.tools,
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Fenrir' } },
          },
          inputAudioTranscription: {},
          outputAudioTranscription: {},
        },
        callbacks: {
          onopen: () => {
            setConnectionState(ConnectionState.CONNECTED);
            
            // Setup Input Processing
            if (!inputAudioContextRef.current || !streamRef.current) return;
            
            inputSourceRef.current = inputAudioContextRef.current.createMediaStreamSource(streamRef.current);
            processorRef.current = inputAudioContextRef.current.createScriptProcessor(4096, 1, 1);
            
            processorRef.current.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              
              // Calculate volume for visualizer
              let sum = 0;
              for (let i = 0; i < inputData.length; i++) {
                sum += inputData[i] * inputData[i];
              }
              const rms = Math.sqrt(sum / inputData.length);
              setVolume(rms);

              const pcmBlob = createPcmBlob(inputData);
              
              if (sessionPromiseRef.current) {
                sessionPromiseRef.current.then(session => {
                  session.sendRealtimeInput({ media: pcmBlob });
                });
              }
            };

            inputSourceRef.current.connect(processorRef.current);
            processorRef.current.connect(inputAudioContextRef.current.destination);
          },
          onmessage: async (message: LiveServerMessage) => {
            // Handle Transcription
            if (message.serverContent?.outputTranscription) {
              const text = message.serverContent.outputTranscription.text;
              currentOutputRef.current += text;
              setRealtimeModel(currentOutputRef.current);
            } else if (message.serverContent?.inputTranscription) {
              const text = message.serverContent.inputTranscription.text;
              currentInputRef.current += text;
              setRealtimeUser(currentInputRef.current);
            }

            if (message.serverContent?.turnComplete) {
              const newMessages: ChatMessage[] = [];
              if (currentInputRef.current.trim()) {
                newMessages.push({ role: 'user', text: currentInputRef.current.trim() });
              }
              if (currentOutputRef.current.trim()) {
                newMessages.push({ role: 'model', text: currentOutputRef.current.trim() });
              }
              
              if (newMessages.length > 0) {
                setConversation(prev => [...prev, ...newMessages]);
              }

              // Clear buffers
              currentInputRef.current = '';
              currentOutputRef.current = '';
              setRealtimeUser('');
              setRealtimeModel('');
            }

             // Handle Tool Calls (The Order Submission)
            if (message.toolCall) {
              for (const fc of message.toolCall.functionCalls) {
                if (fc.name === 'submitOrder') {
                  const order = fc.args as unknown as OrderDetails;
                  setCompletedOrder(order);
                  
                  // Respond to the tool call
                  if (sessionPromiseRef.current) {
                    sessionPromiseRef.current.then(session => {
                      session.sendToolResponse({
                        functionResponses: {
                          id: fc.id,
                          name: fc.name,
                          response: { result: "Order logged successfully." }
                        }
                      });
                    });
                  }
                }
              }
            }

            // Handle Audio Output
            const base64Audio = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            if (base64Audio && outputAudioContextRef.current && outputNodeRef.current) {
              const ctx = outputAudioContextRef.current;
              
              nextStartTimeRef.current = Math.max(
                nextStartTimeRef.current,
                ctx.currentTime
              );

              const audioBuffer = await decodeAudioData(
                base64ToUint8Array(base64Audio),
                ctx,
                24000,
                1
              );

              const source = ctx.createBufferSource();
              source.buffer = audioBuffer;
              source.connect(outputNodeRef.current);
              
              source.addEventListener('ended', () => {
                audioSourcesRef.current.delete(source);
              });

              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += audioBuffer.duration;
              audioSourcesRef.current.add(source);
            }

            // Handle Interruption
            if (message.serverContent?.interrupted) {
               audioSourcesRef.current.forEach(src => {
                 try { src.stop(); } catch(e) {}
               });
               audioSourcesRef.current.clear();
               nextStartTimeRef.current = 0;
               // If interrupted, we might want to push what we have or clear it.
               // Let's finalize current output if it exists.
               if (currentOutputRef.current.trim()) {
                 setConversation(prev => [...prev, { role: 'model', text: currentOutputRef.current.trim() + " [Interrupted]" }]);
               }
               currentOutputRef.current = '';
               setRealtimeModel('');
            }
          },
          onclose: () => {
            if (connectionState === ConnectionState.CONNECTED) {
               disconnect();
            }
          },
          onerror: (e) => {
            console.error("Gemini Live Error", e);
            setError("Connection error. Please retry.");
            disconnect();
          }
        }
      });

      sessionPromiseRef.current = sessionPromise;

    } catch (err: any) {
      console.error(err);
      setError(err.message || "Failed to connect");
      setConnectionState(ConnectionState.ERROR);
    }
  }, [disconnect, connectionState]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      disconnect();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return {
    connect,
    disconnect,
    connectionState,
    volume,
    completedOrder,
    error,
    conversation,
    realtimeUser,
    realtimeModel
  };
};
