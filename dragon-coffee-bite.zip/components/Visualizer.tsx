import React from 'react';

interface VisualizerProps {
  volume: number;
  isActive: boolean;
}

export const Visualizer: React.FC<VisualizerProps> = ({ volume, isActive }) => {
  // Normalize volume for visualization
  const intensity = Math.min(1, volume * 5); 
  
  return (
    <div className="relative w-64 h-64 flex items-center justify-center">
      {/* Outer Glow */}
      <div 
        className={`absolute inset-0 rounded-full bg-dragon-gold opacity-10 blur-xl transition-all duration-100 ease-out`}
        style={{ transform: `scale(${1 + intensity * 0.5})` }}
      />
      
      {/* Middle Ring */}
      <div 
        className="absolute inset-4 rounded-full border-2 border-dragon-gold opacity-30 animate-pulse-slow"
      />

      {/* Dragon Eye / Core */}
      <div 
        className={`relative z-10 w-32 h-32 rounded-full flex items-center justify-center bg-gradient-to-br from-dragon-scale to-dragon-dark border-4 ${isActive ? 'border-dragon-gold shadow-[0_0_30px_rgba(251,191,36,0.5)]' : 'border-dragon-smoke border-opacity-30'} transition-all duration-300`}
      >
        <div 
          className={`w-4 h-16 bg-dragon-gold rounded-full shadow-[0_0_20px_#fbbf24] transition-all duration-100 ease-linear`}
          style={{ 
            height: `${40 + intensity * 60}%`,
            opacity: isActive ? 0.8 + intensity * 0.2 : 0.2 
          }}
        />
      </div>

      {/* Particles */}
      {isActive && (
        <div className="absolute inset-0 animate-spin-slow pointer-events-none">
          <div className="absolute top-0 left-1/2 w-1 h-1 bg-dragon-fire rounded-full shadow-lg" />
          <div className="absolute bottom-10 right-10 w-1 h-1 bg-dragon-leaf rounded-full shadow-lg" />
        </div>
      )}
    </div>
  );
};
