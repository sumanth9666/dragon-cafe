import React from 'react';
import { OrderDetails } from '../types';

interface OrderCardProps {
  order: OrderDetails | null;
}

export const OrderCard: React.FC<OrderCardProps> = ({ order }) => {
  if (!order) return null;

  return (
    <div className="mt-8 p-6 bg-dragon-scale/50 border border-dragon-gold/30 rounded-lg max-w-md w-full backdrop-blur-sm animate-float shadow-xl">
      <h3 className="text-xl font-serif text-dragon-gold mb-4 text-center border-b border-dragon-gold/20 pb-2">
        🔥 Enchanted Order Brewed
      </h3>
      <div className="space-y-3 font-sans text-dragon-smoke">
        <div className="flex justify-between">
          <span className="font-bold text-dragon-leaf">Customer:</span>
          <span>{order.name}</span>
        </div>
        <div className="flex justify-between">
          <span className="font-bold text-dragon-leaf">Drink:</span>
          <span className="capitalize">{order.drinkType}</span>
        </div>
        <div className="flex justify-between">
          <span className="font-bold text-dragon-leaf">Size:</span>
          <span className="capitalize">{order.size}</span>
        </div>
        <div className="flex justify-between">
          <span className="font-bold text-dragon-leaf">Milk:</span>
          <span className="capitalize">{order.milk}</span>
        </div>
        <div className="flex justify-between flex-col sm:flex-row">
          <span className="font-bold text-dragon-leaf">Extras:</span>
          <div className="flex flex-wrap gap-1 justify-end">
            {order.extras && order.extras.length > 0 ? (
              order.extras.map((extra, i) => (
                <span key={i} className="text-sm bg-dragon-dark/50 px-2 py-0.5 rounded border border-dragon-gold/10">
                  {extra}
                </span>
              ))
            ) : (
              <span>None</span>
            )}
          </div>
        </div>
      </div>
      
      <div className="mt-6 pt-4 border-t border-dragon-gold/20">
        <p className="text-xs text-dragon-smoke/50 uppercase tracking-widest mb-2">Raw Rune Script (JSON)</p>
        <pre className="bg-dragon-dark p-3 rounded text-xs text-green-400 overflow-x-auto font-mono">
          {JSON.stringify(order, null, 2)}
        </pre>
      </div>
    </div>
  );
};
