import React, { useEffect, useRef } from 'react';
import { ChatMessage } from '../types';

interface ConversationBoxProps {
  conversation: ChatMessage[];
  realtimeUser: string;
  realtimeModel: string;
}

export const ConversationBox: React.FC<ConversationBoxProps> = ({ 
  conversation, 
  realtimeUser, 
  realtimeModel 
}) => {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [conversation, realtimeUser, realtimeModel]);

  // If no conversation, show nothing to keep the Sage clear
  if (conversation.length === 0 && !realtimeUser && !realtimeModel) {
    return null;
  }

  return (
    <div className="w-full h-full px-4">
      {/* Scrollable Container */}
      <div 
        ref={scrollRef}
        className="h-full overflow-y-auto custom-scrollbar space-y-4 p-2 mask-linear"
      >
        {/* Spacer to push content to the bottom initially if needed, or just let it fill */}
        
        {conversation.map((msg, index) => (
          <div 
            key={index} 
            className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div 
              className={`max-w-[85%] px-4 py-2 rounded-2xl text-sm backdrop-blur-sm shadow-lg ${
                msg.role === 'user' 
                  ? 'bg-dragon-scale/80 text-dragon-smoke rounded-br-none border border-dragon-leaf/30' 
                  : 'bg-dragon-dark/80 text-dragon-gold/90 rounded-bl-none border-l-2 border-dragon-gold/70'
              }`}
            >
              {msg.text}
            </div>
          </div>
        ))}

        {realtimeUser && (
          <div className="flex justify-end animate-pulse">
            <div className="max-w-[85%] px-4 py-2 rounded-2xl text-sm bg-dragon-scale/60 text-dragon-smoke/80 rounded-br-none border border-dragon-leaf/20 italic backdrop-blur-sm">
              {realtimeUser}...
            </div>
          </div>
        )}

        {realtimeModel && (
          <div className="flex justify-start animate-pulse">
            <div className="max-w-[85%] px-4 py-2 rounded-2xl text-sm bg-dragon-dark/60 text-dragon-gold/80 rounded-bl-none border-l-2 border-dragon-gold/40 italic backdrop-blur-sm">
               {realtimeModel}...
            </div>
          </div>
        )}
      </div>
      
      <style jsx>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(251, 191, 36, 0.1);
          border-radius: 2px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: rgba(251, 191, 36, 0.3);
        }
        .mask-linear {
            mask-image: linear-gradient(to bottom, transparent, black 10%, black 90%, transparent);
            -webkit-mask-image: linear-gradient(to bottom, transparent, black 10%, black 90%, transparent);
        }
      `}</style>
    </div>
  );
};