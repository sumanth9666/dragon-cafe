import React from 'react';
import { useDragonSage } from './hooks/useDragonSage';
import { Visualizer } from './components/Visualizer';
import { OrderCard } from './components/OrderCard';
import { ConversationBox } from './components/ConversationBox';
import { ConnectionState } from './types';

const App: React.FC = () => {
  const { 
    connect, 
    disconnect, 
    connectionState, 
    volume, 
    completedOrder, 
    error,
    conversation,
    realtimeUser,
    realtimeModel
  } = useDragonSage();

  const isConnected = connectionState === ConnectionState.CONNECTED;
  const isConnecting = connectionState === ConnectionState.CONNECTING;

  const handleToggleConnection = () => {
    if (isConnected) {
      disconnect();
    } else {
      connect();
    }
  };

  return (
    <div className="min-h-screen bg-dragon-dark flex flex-col items-center p-4 relative bg-[url('https://images.unsplash.com/photo-1514933651103-005eec06c04b?q=80&w=2874&auto=format&fit=crop')] bg-cover bg-center overflow-y-auto">
      {/* Overlay to darken background */}
      <div className="fixed inset-0 bg-dragon-dark/90 backdrop-blur-sm z-0" />

      {/* Main Content */}
      <div className="relative z-10 flex flex-col items-center w-full max-w-2xl pt-10 pb-10">
        
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl md:text-6xl font-serif text-dragon-gold mb-2 drop-shadow-lg tracking-wider">
            Dragon Coffee Bite
          </h1>
          <p className="text-dragon-smoke font-sans text-lg tracking-wide">
            Where Wisdom Meets the Brew
          </p>
        </div>

        {/* Central Display: Sage Visualizer + Conversation Overlay */}
        <div className="relative w-full h-[400px] flex items-center justify-center mb-8 group">
          
          {/* Background: Dragon Sage Visualizer */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none transition-all duration-700">
             <div className={`transform transition-all duration-700 ${conversation.length > 0 ? 'scale-125 opacity-50' : 'scale-110 opacity-100'}`}>
                <Visualizer volume={volume} isActive={isConnected} />
             </div>
          </div>

          {/* Foreground: Conversation Box */}
          <div className="relative z-10 w-full h-full flex items-center justify-center">
            <ConversationBox 
              conversation={conversation} 
              realtimeUser={realtimeUser} 
              realtimeModel={realtimeModel} 
            />
          </div>

        </div>

        {/* Controls */}
        <div className="flex flex-col items-center space-y-4 w-full mb-6">
          <button
            onClick={handleToggleConnection}
            disabled={isConnecting}
            className={`
              group relative px-8 py-4 rounded-full font-serif font-bold text-lg tracking-widest transition-all duration-300
              ${isConnected 
                ? 'bg-dragon-fire/10 border-2 border-dragon-fire text-dragon-fire hover:bg-dragon-fire hover:text-white' 
                : 'bg-dragon-gold/10 border-2 border-dragon-gold text-dragon-gold hover:bg-dragon-gold hover:text-dragon-dark shadow-[0_0_20px_rgba(251,191,36,0.3)]'}
              disabled:opacity-50 disabled:cursor-not-allowed
            `}
          >
            <span className="relative z-10 flex items-center gap-3">
              {isConnecting ? (
                <>
                  <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                  </svg>
                  Summoning...
                </>
              ) : isConnected ? (
                <>
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                  Dismiss Sage
                </>
              ) : (
                <>
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z"></path></svg>
                  Awaken Dragon Sage
                </>
              )}
            </span>
          </button>
          
          <div className="h-6">
            {error && (
              <p className="text-dragon-fire text-sm font-bold animate-pulse">{error}</p>
            )}
            {!error && isConnected && (
              <p className="text-dragon-leaf text-sm animate-fade-in">The Sage is listening...</p>
            )}
          </div>
        </div>

        {/* Order Result */}
        <OrderCard order={completedOrder} />
        
        {/* Instructions */}
        {!isConnected && !completedOrder && conversation.length === 0 && (
          <div className="mt-8 text-center max-w-md text-dragon-smoke/60 text-sm">
            <p>Click "Awaken" to speak. Ask the Dragon Sage for wisdom, or say <span className="text-dragon-gold">"I'd like to order a coffee"</span> to visit the bar.</p>
          </div>
        )}

      </div>
    </div>
  );
};

export default App;