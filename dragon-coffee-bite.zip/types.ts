export interface OrderDetails {
  drinkType: string;
  size: string;
  milk: string;
  extras: string[];
  name: string;
}

export enum ConnectionState {
  DISCONNECTED = 'DISCONNECTED',
  CONNECTING = 'CONNECTING',
  CONNECTED = 'CONNECTED',
  ERROR = 'ERROR',
}

export interface AudioVisualizerData {
  volume: number;
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}
